#!/bin/sh

docker build . -t wit
docker run --rm -v $(pwd):/src -p 4444:4444 -it wit